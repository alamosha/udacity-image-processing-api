import path from 'path';

const cachedImageDir = path.join(__dirname, '../../images/cached');
const originalImageDir = path.join(__dirname, '../../images/original');

export { cachedImageDir, originalImageDir };
